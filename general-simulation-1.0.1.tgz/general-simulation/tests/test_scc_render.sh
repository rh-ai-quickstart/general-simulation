#!/usr/bin/env bash
# Guardrails: default chart render must not require cluster-admin SCC bindings.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NS="${1:-helm-scc-test}"

render() {
  helm template scc-test "$CHART_DIR" \
    --namespace "$NS" \
    --set postgres.postgres.password=demo \
    --set api.postgres.password=demo \
    --set api.neo4j.password=demo \
    --set bootstrap.postgres.password=demo \
    --set bootstrap.neo4j.password=demo \
    --set neo4j.disableLookups=true \
    "$@"
}

fail() {
  echo "SCC render test FAILED: $*" >&2
  exit 1
}

echo "==> Checking default render has no ClusterRoleBindings or fixed UIDs..."
manifest="$(render)"
if echo "$manifest" | rg -q "kind: ClusterRoleBinding"; then
  fail "default values must not render ClusterRoleBinding (requires cluster-admin)"
fi
if echo "$manifest" | rg -q "runAsUser: 7474|runAsUser: 999"; then
  fail "default values must not pin Neo4j (7474) or Postgres (999) UIDs"
fi

echo "==> Checking legacy anyuid overlay still renders SCC bindings..."
legacy="$(render -f "$CHART_DIR/values-openshift-anyuid.yaml")"
if ! echo "$legacy" | rg -q "kind: ClusterRoleBinding"; then
  fail "values-openshift-anyuid.yaml must render ClusterRoleBindings"
fi
if ! echo "$legacy" | rg -q "${NS}-neo4j-anyuid"; then
  fail "legacy overlay must render neo4j anyuid ClusterRoleBinding"
fi
if ! echo "$legacy" | rg -q "${NS}-postgres-anyuid"; then
  fail "legacy overlay must render postgres anyuid ClusterRoleBinding"
fi
if ! echo "$legacy" | rg -q "runAsUser: 7474"; then
  fail "legacy overlay must pin Neo4j UID 7474"
fi
if ! echo "$legacy" | rg -q "runAsUser: 999"; then
  fail "legacy overlay must pin Postgres UID 999"
fi

echo "==> SCC render tests passed."
